'use strict';

module.exports = {
  name: 'installation'
};
